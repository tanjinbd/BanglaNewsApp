/** Automatically generated file. DO NOT MODIFY */
package air.com.starhostbd.bestnews24;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}